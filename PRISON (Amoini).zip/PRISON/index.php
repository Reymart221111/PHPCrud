<?php require "DashboardDisplay/fetchPrisonerCount.php" ?>
<?php require "DashboardDisplay/fetchCellCount.php" ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prison Management System</title>
    <link rel="stylesheet" href="styles.css">
    <script type="text/javascript">
        function redirectToPage(url) {
            window.location.href = url;
        }

        function searchTable(sectionId, searchInputId) {
            let input = document.getElementById(searchInputId).value.toUpperCase();
            let table = document.querySelector(`#${sectionId} table`);
            let tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                let td = tr[i].getElementsByTagName('td');
                let found = false;
                for (let j = 0; j < td.length; j++) {
                    if (td[j]) {
                        let textValue = td[j].textContent || td[j].innerText;
                        if (textValue.toUpperCase().indexOf(input) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                tr[i].style.display = found ? '' : 'none';
            }
        }
    </script>
    <style>
        /* Add this to your styles.css */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        header {
            background-color: #2c3e50;
            color: orange;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            box-sizing: border-box;
        }

        .header-content {
            display: flex;
            align-items: center;
        }

        .header-nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
        }

        .header-nav ul li {
            margin: 0 10px;
        }

        .header-nav ul li a {
            color: #ecf0f1;
            /* Light grey for text */
            text-decoration: none;
            padding: 10px;
        }

        .header-nav ul li a:hover {
            background-color: #34495e;
            /* Slightly lighter grey-blue */
            border-radius: 4px;
        }

        .main-content {
            display: flex;
            flex: 1;
            height: calc(100vh - 50px);
            /* Adjust height to subtract header height */
        }

        .side-nav {
            background-color: orange;
            /* Match header color */
            width: 200px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            box-sizing: border-box;
            padding-top: 20px;
        }

        .side-nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            width: 100%;
        }

        .side-nav ul li {
            margin: 0;
        }

        .side-nav ul li a {
            display: block;
            padding: 14px 20px;
            text-decoration: none;
            color: blue;
            /* Light grey for text */
            text-align: center;
        }

        .side-nav ul li a:hover {
            background-color: #34495e;
            /* Slightly lighter grey-blue */
        }

        #content {
            padding: 20px;
            width: calc(100% - 200px);
            overflow-y: auto;
            box-sizing: border-box;
        }

        section {
            display: none;
            padding: 20px;
            border: 1px solid #ddd;
            margin-top: 20px;
        }

        section:target {
            display: block;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .search-container {
            text-align: right;
            margin-bottom: 20px;
        }

        .search-container input[type="text"] {
            padding: 6px;
            margin-right: 8px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            padding: 6px 12px;
            font-size: 14px;
            border: none;
            border-radius: 4px;
            background-color: #2c3e50;
            color: #ecf0f1;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #34495e;
        }

        /* Add this to your styles.css */
        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }

        .dashboard-card {
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            flex: 1;
        }

        .dashboard-card h3 {
            margin-bottom: 10px;
            font-size: 1.2em;
        }

        .dashboard-card p {
            font-size: 2em;
            margin: 0;
        }

        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }

        .dashboard-card {
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            flex: 1;
        }

        .dashboard-card h3 {
            margin-bottom: 10px;
            font-size: 1.2em;
        }

        .dashboard-card p {
            font-size: 2em;
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-content">
            <h1>Prison Management System</h1>
            <nav class="header-nav">
                <ul>
                    <li><a href="#home">Home</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="main-content">
        <nav class="side-nav">
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#prisoners">Prisoners</a></li>
                <li><a href="#cells">Cells</a></li>
                <li><a href="#offenses">Offenses</a></li>
                <li><a href="#sentences">Sentences</a></li>
            </ul>
        </nav>

        <div id="content">
            <section id="home">
                <h2>Dashboard</h2>
                <p>Welcome to the Prison Management System Dashboard.</p>
                <div class="dashboard-cards">
                    <div class="dashboard-card">
                        <h3>Total Prisoners</h3>
                        <p><?php echo $prisonCount['count'] ?></p>
                    </div>
                    <div class="dashboard-card">
                        <h3>Total Cells</h3>
                        <p><?php echo $cellCount['count'] ?></p>
                    </div>
                </div>
            </section>

            <section id="prisoners">
                <h2>Prisoners</h2>
                <input type="text" id="searchPrisoners" placeholder="Search Prisoners" onkeyup="searchTable('prisoners', 'searchPrisoners')">
                <table id="prisonerTable">
                    <tr>
                        <th>PrisonerID</th>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>Date Of Birth</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>AdmissionDate</th>
                        <th>Crime Desc</th>
                        <th>Cell Id</th>
                        <th>Cell Block</th>
                        <th>Actions</th>
                    </tr>
                    <tbody>
                        <tr>
                            <?php
                            require "fetchDisplay/fetchPrisoners.php";

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                            ?>

                        <tr>
                            <td><?php echo $row['PrisonerID'] ?></td>
                            <td><?php echo $row['FirstName'] ?></td>
                            <td><?php echo $row['LastName'] ?></td>
                            <td><?php echo $row['DateOfBirth'] ?></td>
                            <td><?php echo $row['Age'] ?></td>
                            <td><?php echo $row['Gender'] ?></td>
                            <td><?php echo $row['AdmissionDate'] ?></td>
                            <td><?php echo $row['CrimeDesc'] ?></td>
                            <td><?php echo $row['CellID'] ?></td>
                            <td><?php echo $row['CellBlock'] ?></td>
                            <td>
                                <button class="edit-btn" onclick="redirectToPage('editting_record/editting_prisoner.php?id=<?php echo $row['PrisonerID']; ?>')">Edit</button>
                                <button class="delete-btn" onclick="redirectToPage('deleteProcess/delete.prisoner.php?id=<?php echo $row['PrisonerID']; ?>')">Delete</button>
                            </td>
                        </tr>
                <?php
                                }
                            }
                ?>
                </tr>
                    </tbody>
                </table>
                <button onclick="redirectToPage('adding_record/adding_prisoner.php')">Add Prisoner</button>
            </section>

            <section id="cells">
                <h2>Cells</h2>
                <input type="text" id="searchCells" placeholder="Search Cells" onkeyup="searchTable('cells', 'searchCells')">
                <table>
                    <tr>
                        <th>CellID</th>
                        <th>Block</th>
                        <th>CellType</th>
                        <th>Cell Description</th>
                        <th>Actions</th>
                    </tr>
                    <tbody>
                        <tr>
                            <?php
                            require "fetchDisplay/fetchCells.php";

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                            ?>

                        <tr>
                            <td><?php echo $row['CellID'] ?></td>
                            <td><?php echo $row['Block'] ?></td>
                            <td><?php echo $row['CellType'] ?></td>
                            <td><?php echo $row['Cell_Description'] ?></td>
                            <td>
                                <button class="edit-btn" onclick="redirectToPage('editting_record/editting_cells.php?id=<?php echo $row['CellID']; ?>')">Edit</button>
                                <button class="delete-btn" onclick="redirectToPage('deleteProcess/delete.cell.php?id=<?php echo $row['CellID']; ?>')">Delete</button>
                            </td>
                        </tr>
                <?php
                                }
                            }
                ?>
                </tr>
                    </tbody>
                </table>
                <button onclick="redirectToPage('adding_record/adding_cells.php')">Add Cells</button>
            </section>

            <section id="offenses">
                <h2>Offenses</h2>
                <input type="text" id="searchOffenses" placeholder="Search Offenses" onkeyup="searchTable('offenses', 'searchOffenses')">
                <table>
                    <tr>
                        <th>OffenseID</th>
                        <th>PrisonerID</th>
                        <th>Prisoner Name</th>        
                        <th>Offense</th>
                        <th>OffenseDate</th>
                        <th>Actions</th>
                    </tr>
                    <tbody>
                        <tr>
                            <?php
                            require "fetchDisplay/fetchOffenses.php";

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                            ?>

                        <tr>
                            <td><?php echo $row['OffenseID'] ?></td>
                            <td><?php echo $row['PrisonerID'] ?></td>
                            <td><?php echo $row['FullName'] ?></td>
                            <td><?php echo $row['OffenseDesc'] ?></td>
                            <td><?php echo $row['OffenseDate'] ?></td>
                            <td>
                                <button class="edit-btn" onclick="redirectToPage('editting_record/editting_offense.php?id=<?php echo $row['OffenseID']; ?>')">Edit</button>
                                <button class="delete-btn" onclick="redirectToPage('deleteProcess/delete.offense.php?id=<?php echo $row['OffenseID']; ?>')">Delete</button>
                            </td>
                        </tr>
                <?php
                                }
                            }
                ?>
                </tr>
                    </tbody>
                </table>
                <button onclick="redirectToPage('adding_record/adding_offenses.php')">Add Offenses</button>
            </section>

            <section id="sentences">
                <h2>Sentences</h2>
                <input type="text" id="searchSentences" placeholder="Search Sentences" onkeyup="searchTable('sentences', 'searchSentences')">
                <table>
                    <tr>
                        <th>SentenceID</th>
                        <th>PrisonerID</th>
                        <th>Prisoner Name</th>  
                        <th>SentenceType</th>
                        <th>SentenceStart</th>
                        <th>SentenceEnd</th>
                        <th>Actions</th>
                    </tr>
                    <tbody>
                        <tr>
                            <?php
                            require "fetchDisplay/fetchSentences.php";

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                            ?>

                        <tr>
                            <td><?php echo $row['SentenceID'] ?></td>
                            <td><?php echo $row['PrisonerID'] ?></td>
                            <td><?php echo $row['FullName'] ?></td>
                            <td><?php echo $row['SentenceType'] ?></td>
                            <td><?php echo $row['SentenceStart'] ?></td>
                            <td><?php echo $row['SentenceEnd'] ?></td>
                            <td>
                                <button class="edit-btn" onclick="redirectToPage('editting_record/editting_sentences.php?id=<?php echo $row['SentenceID']; ?>')">Edit</button>
                                <button class="delete-btn" onclick="redirectToPage('deleteProcess/delete.sentence.php?id=<?php echo $row['SentenceID']; ?>')">Delete</button>
                            </td>
                        </tr>
                <?php
                                }
                            }
                ?>
                </tr>
                    </tbody>
                </table>
                <button onclick="redirectToPage('adding_record/add_sentences.php')">Prisoner Sentences</button>
            </section>
        </div>
    </div>
</body>

</html>