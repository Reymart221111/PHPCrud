<?php

try {
    $servername = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "Prison";

    $connection = new mysqli($servername, $dbuser, $dbpass);

    // Create Database
    $sql_create_database = "CREATE DATABASE IF NOT EXISTS " . $dbname;

    if ($connection->query($sql_create_database) === TRUE) {
        echo "";
    }

    $connection->select_db($dbname);

    // Create Cells Table
    $sql_create_table = "CREATE TABLE IF NOT EXISTS Cells (
        CellID INT AUTO_INCREMENT PRIMARY KEY,
        Block VARCHAR(50) UNIQUE NOT NULL,
        CellType VARCHAR(50) NOT NULL,
        Cell_Description TEXT
    ) ENGINE=InnoDB;";

    if ($connection->query($sql_create_table)) {
        echo "";
    }

    // Create Prisoners Table
    $sql_create_table = "CREATE TABLE IF NOT EXISTS Prisoners (
        PrisonerID INT AUTO_INCREMENT PRIMARY KEY,
        FirstName VARCHAR(50) NOT NULL,
        LastName VARCHAR(50) NOT NULL,
        DateOfBirth DATE NOT NULL,
        Gender CHAR(1) NOT NULL,
        CrimeDesc TEXT,
        AdmissionDate DATE NOT NULL,
        CellID INT,
        FOREIGN KEY (CellID) REFERENCES Cells(CellID)
            ON DELETE CASCADE
            ON UPDATE CASCADE
    ) ENGINE=InnoDB;";

    if ($connection->query($sql_create_table)) {
        echo "";
    }

    // Create Offenses Table
    $sql_create_table = "CREATE TABLE IF NOT EXISTS Offenses (
        OffenseID INT AUTO_INCREMENT PRIMARY KEY,
        PrisonerID INT,
        OffenseDesc TEXT NOT NULL,
        OffenseDate DATE NOT NULL,
        FOREIGN KEY (PrisonerID) REFERENCES Prisoners(PrisonerID)
            ON DELETE CASCADE
            ON UPDATE CASCADE
    ) ENGINE=InnoDB;";

    if ($connection->query($sql_create_table)) {
        echo "";
    }

    // Create Sentences Table
    $sql_create_table = "CREATE TABLE IF NOT EXISTS Sentences (
       SentenceID INT AUTO_INCREMENT PRIMARY KEY,
        PrisonerID INT,
        SentenceType VARCHAR(100) NOT NULL,
        SentenceStart DATE NOT NULL,
        SentenceEnd DATE NOT NULL,
        FOREIGN KEY (PrisonerID) REFERENCES Prisoners(PrisonerID)
            ON DELETE CASCADE
            ON UPDATE CASCADE
    ) ENGINE=InnoDB;";

    if ($connection->query($sql_create_table)) {
        echo "";
    }

} catch (Exception $error) {
    echo "Error->" . $error->getMessage();
}
?>
