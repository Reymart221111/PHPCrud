<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Cells</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        h3 {
            color: #333333;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #555555;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            padding: 10px 20px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3>Adding Cells<?php include "../Messages/error_messages.php" ?></h3>
        <form id="prisonerForm" action="../adding_process/add.cell.process.php" method="post">
            <label for="block">Block</label>
            <input type="text" id="block" name="block" required>

            <label for="cell type">Cell Type</label>
            <select id="celltype" name="celltype" required>
                <option value="Solitary">Solitary</option>
                <option value="Regular">Regular</option>
                <option value="Super Max">Super Max</option>
            </select>

            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4" cols="38"></textarea>


            <input type="submit" value="Add Cell">
            <p>
                <center><a href="../index.php#cells" style="font-size: 30px;">Exit</a></center>
            </p>
        </form>
    </div>
</body>

</html>