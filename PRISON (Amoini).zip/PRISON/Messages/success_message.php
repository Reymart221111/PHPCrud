<?php
$success_message = isset($_GET['success']) ? $_GET['success'] : '';
if (!empty($success_message)) {
    echo '<p style="color: green;">' . htmlspecialchars($success_message) . '</p>';
}

