<?php
$error = isset($_GET['error']) ? $_GET['error'] : ""; 
if (!empty($error)) {
    echo '<p style="color: red;">' . htmlspecialchars($error) . '</p>';
}
