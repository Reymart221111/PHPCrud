<?php
try {
    require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";

    $stmt = $connection->prepare("
    SELECT 
        Offenses.*,
        CONCAT(Prisoners.FirstName, ' ', Prisoners.LastName) AS FullName
    FROM Offenses
    JOIN Prisoners ON Offenses.PrisonerID = Prisoners.PrisonerID
");
    $stmt->execute();
    $result = $stmt->get_result();
} catch (Exception $error) {
    echo "Error->" . $error->getMessage();
}
