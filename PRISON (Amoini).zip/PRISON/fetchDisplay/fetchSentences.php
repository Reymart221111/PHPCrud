<?php
try {
    require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";
    $stmt = $connection->prepare("
    SELECT 
        Sentences.*,
        CONCAT(Prisoners.FirstName, ' ', Prisoners.LastName) AS FullName
    FROM Sentences
    JOIN Prisoners ON Sentences.PrisonerID = Prisoners.PrisonerID
");
    $stmt->execute();
    $result = $stmt->get_result();
} catch (Exception $error) {
    echo "Error->" . $error->getMessage();
}
