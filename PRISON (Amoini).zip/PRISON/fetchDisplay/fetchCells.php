<?php
try {
    require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";
    $stmt = $connection->prepare("SELECT * FROM Cells");
    $stmt->execute();
    $result = $stmt->get_result();
} catch (Exception $error) {
    echo "Error->" . $error->getMessage();
}
