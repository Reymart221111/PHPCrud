<?php

$servername = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "Prison";

$connection = new mysqli($servername, $dbuser, $dbpass, $dbname);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Query to get prisoner data along with calculated age
$sql = "
    SELECT 
        p.PrisonerID, 
        p.FirstName, 
        p.LastName, 
        p.DateOfBirth, 
        p.Gender, 
        p.CrimeDesc, 
        p.AdmissionDate, 
        p.CellID,
        c.Block AS CellBlock,
        TIMESTAMPDIFF(YEAR, p.DateOfBirth, CURDATE()) AS Age
    FROM 
        Prisoners p
    LEFT JOIN 
        Cells c ON p.CellID = c.CellID
";

$stmt = $connection->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

