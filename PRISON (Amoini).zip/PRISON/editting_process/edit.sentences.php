<?php

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $record_id = $_GET['id'];
    $prisoner_id = $_POST['p_id'];
    $sentenceType = $_POST['sentence_type'];
    $sentenceStart = $_POST['sentence_start'];
    $sentenceEnd = $_POST['sentence_end'];

    try {
        require "../DBSETUP/dbsetup.php";


        if (!IsCellIdValid($prisoner_id, $connection)) {
            $message = 'Prisoner ID does not Exist';
            header("Location: ../editing_record/editting_sentences?error=" . urlencode($message));
            exit();
        }
        $stmt = $connection->prepare("UPDATE Sentences SET PrisonerId = ?, SentenceType = ?, SentenceStart = ?, SentenceEnd = ? WHERE SentenceID = ?");

        $stmt->bind_param('isssi',  $prisoner_id, $sentenceType, $sentenceStart, $sentenceEnd, $record_id);

        if ($stmt->execute()) {
            $message = "Record Edited Succesfully!";
            header("Location: ../index.php?success=".urlencode($message)."#sentences");
            exit();
        }
    } catch (Exception $error) {
        echo "Error->" . $error->getMessage();
        // $message = "Block Already Exist";
        // header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
        // exit();
    }
}

function IsCellIdValid($prisoner_id, $connection)
{
    $stmt = $connection->prepare("SELECT * FROM prisoners where PrisonerID = ?");
    $stmt->bind_param('i', $prisoner_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return true;
    } else {
        return false;
    }
}
