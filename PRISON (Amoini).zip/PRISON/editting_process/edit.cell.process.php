<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $record_id = $_GET['id'];
    $block = $_POST['block'];
    $cellType = $_POST['celltype'];
    $description = $_POST['description'];

    try {
        require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";

        $stmt = $connection->prepare('UPDATE cells SET Block = ?, CellType = ?, Cell_Description = ? WHERE CellID = ?');
        $stmt->bind_param('sssi',$block, $cellType, $description, $record_id);

        if($stmt->execute())
        {
            $message = "Record Edited Succesfully";
            header("Location: ../index.php?success=".urlencode($message)."#cells");
            exit();
        }
    } catch (Exception $error) {
        echo "error->" . $error->getMessage();
        $message = "Block Already Exist";
        header("Location: ../editting_record/editting_cells.php?id=" . $record_id . "&error=" . urlencode($message));
        exit();
    }
}
