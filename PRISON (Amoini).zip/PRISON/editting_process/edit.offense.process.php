<?php

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $record_id = $_GET['id'];
    $prisoner_id = $_POST['p_id'];
    $Offense = $_POST['offense_type'];
    $OffenseDate = $_POST['offence_date'];

    try {
        require "../DBSETUP/dbsetup.php";


        if (!IsCellIdValid($prisoner_id, $connection)) {
            $message = 'Prisoner ID does not Exist';
            header("Location: ../editting_record/editting_offenses.php?id=" . $record_id . "&error=" . urlencode($message));
            exit();
        }
        $stmt = $connection->prepare("UPDATE offenses SET PrisonerId = ?, OffenseDesc=?, OffenseDate=? WHERE OffenseID = ?");
        $stmt->bind_param('issi',  $prisoner_id, $Offense, $OffenseDate, $record_id);

        if ($stmt->execute()) {
            $message = "Record Edited Succesfully";
            header("Location: ../index.php?success=".urlencode($message)."#offenses");
            exit();
        }
    } catch (Exception $error) {
        echo "Error->" . $error->getMessage();
        // $message = "Block Already Exist";
        // header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
        // exit();
    }
}

function IsCellIdValid($prisoner_id, $connection)
{
    $stmt = $connection->prepare("SELECT * FROM prisoners where PrisonerID = ?");
    $stmt->bind_param('i', $prisoner_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return true;
    } else {
        return false;
    }
}
