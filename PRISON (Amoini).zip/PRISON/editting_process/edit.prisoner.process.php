<?php

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $record_id = $_GET['id'];
    $firstName = $_POST['firstName'];
    $LastName = $_POST['lastName'];
    $DateOfBirth = $_POST['dateOfBirth'];
    $gender = $_POST['gender'];
    $AdmissionDate = $_POST['admissionDate'];
    $crimeDesc = $_POST['description'];
    $CellID = $_POST['cellid'];

    try {
        require "../DBSETUP/dbsetup.php";


        if (!IsCellIdValid($CellID, $connection)) {
            $message = 'Cell ID does not Exist';
            header("Location: ../editting_record/editting_prisoner.php?id=" . $record_id . "&error=" . urlencode($message));
            exit();
        }
        $stmt = $connection->prepare("UPDATE prisoners SET FirstName=?, LastName=?, DateOfBirth=?, Gender=?, AdmissionDate=?,CrimeDesc=?, CellID=? where PrisonerID = ?");
        $stmt->bind_param('ssssssii',  $firstName, $LastName, $DateOfBirth, $gender, $AdmissionDate, $crimeDesc, $CellID, $record_id);

        if ($stmt->execute()) {
            $message = "Record Edited Succesfully";
            header("Location: ../index.php?success=" . urlencode($message) . "#prisoners");
            exit();
        }
    } catch (Exception $error) {
        echo "Error->" . $error->getMessage();
        // $message = "Block Already Exist";
        // header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
        // exit();
    }
}

function IsCellIdValid($CellID, $connection)
{
    $stmt = $connection->prepare("SELECT * FROM cells where CellID = ?");
    $stmt->bind_param('i', $CellID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return true;
    } else {
        return false;
    }
}
