<?php

if($_SERVER['REQUEST_METHOD'] === "POST")
{
    $firstName = $_POST['firstName'];
    $LastName = $_POST['lastName'];
    $DateOfBirth = $_POST['dateOfBirth'];
    $gender = $_POST['gender'];
    $AdmissionDate = $_POST['admissionDate'];
    $crimeDesc = $_POST['description'];
    $CellID = $_POST['cellid'];
  
    try {
        require "../DBSETUP/dbsetup.php";


        if(!IsCellIdValid($CellID, $connection)){
            $message = 'Cell ID does not Exist';
            header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
            exit();
        }
        $stmt = $connection->prepare("INSERT INTO prisoners(FirstName, LastName, DateOfBirth, Gender, AdmissionDate, CrimeDesc, CellID) VALUES(?,?,?,?,?,?,?)");
        $stmt->bind_param('ssssssi',  $firstName, $LastName, $DateOfBirth, $gender, $AdmissionDate, $crimeDesc, $CellID);

        if($stmt->execute()){
            $message = "Prisoner Data Added!";
            header("Location: ../index.php?success=".urlencode($message)."#prisoners");
            exit();
        }
    
    } catch (Exception $error) {
        echo "Error->".$error->getMessage();
       // $message = "Block Already Exist";
       // header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
       // exit();
    }

}

function IsCellIdValid($CellID, $connection){
   $stmt = $connection->prepare("SELECT * FROM cells where CellID = ?");
   $stmt->bind_param('i', $CellID);
   $stmt->execute();
   $result = $stmt->get_result();

   if($result->num_rows === 1)
   {
    return true;
   }else{
    return false;
   }
}