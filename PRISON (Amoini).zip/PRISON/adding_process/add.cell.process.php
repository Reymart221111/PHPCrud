<?php

if($_SERVER['REQUEST_METHOD'] === "POST")
{
    $block = $_POST['block'];
    $cellType = $_POST['celltype'];
    $description = $_POST['description'];

    try {
        require "../DBSETUP/dbsetup.php";
        $stmt = $connection->prepare("INSERT INTO Cells(Block, CellType, Cell_Description) VALUES(?,?,?)");
        $stmt->bind_param('sss', $block, $cellType, $description);

        if($stmt->execute()){
            $message = "Added Succesfully";
            header("Location: ../index.php?success=".urlencode($message)."#cells");
            exit();
        }
    } catch (Exception $error) {
        echo "Error->".$error->getMessage();
        $message = "Block Already Exist";
        header("Location: ../adding_record/adding_cells.php?error=".urlencode($message));
        exit();
    }

}