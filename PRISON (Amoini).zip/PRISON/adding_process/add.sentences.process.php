<?php

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $prisoner_id = $_POST['p_id'];
    $sentenceType = $_POST['sentence_type'];
    $sentenceStart = $_POST['sentence_start'];
    $sentenceEnd = $_POST['sentence_end'];

    try {
        require "../DBSETUP/dbsetup.php";


        if (!IsCellIdValid($prisoner_id, $connection)) {
            $message = 'Prisoner ID does not Exist';
            header("Location: ../adding_record/add_sentences?error=" . urlencode($message));
            exit();
        }
        $stmt = $connection->prepare("INSERT INTO sentences(PrisonerId, SentenceType, SentenceStart, SentenceEnd) VALUES(?,?,?,?)");
        $stmt->bind_param('isss',  $prisoner_id, $sentenceType, $sentenceStart, $sentenceEnd);

        if ($stmt->execute()) {
            $message = "Added Succesfully";
            header("Location: ../index.php?success=".urlencode($message)."#sentences");
            exit();
        }
    } catch (Exception $error) {
        echo "Error->" . $error->getMessage();
        // $message = "Block Already Exist";
        // header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
        // exit();
    }
}

function IsCellIdValid($prisoner_id, $connection)
{
    $stmt = $connection->prepare("SELECT * FROM prisoners where PrisonerID = ?");
    $stmt->bind_param('i', $prisoner_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return true;
    } else {
        return false;
    }
}
