<?php

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $prisoner_id = $_POST['p_id'];
    $Offense = $_POST['offense_type'];
    $OffenseDate = $_POST['offence_date'];

    try {
        require "../DBSETUP/dbsetup.php";


        if (!IsCellIdValid($prisoner_id, $connection)) {
            $message = 'Prisoner ID does not Exist';
            header("Location: ../adding_record/adding_offenses?error=" . urlencode($message));
            exit();
        }
        $stmt = $connection->prepare("INSERT INTO offenses(PrisonerId, OffenseDesc, OffenseDate) VALUES(?,?,?)");
        $stmt->bind_param('iss',  $prisoner_id, $Offense, $OffenseDate);

        if ($stmt->execute()) {
            $message = "Added Succesfully";
            header("Location: ../index.php?success=".urlencode($message)."#offenses");
            exit();
        }
    } catch (Exception $error) {
        echo "Error->" . $error->getMessage();
        // $message = "Block Already Exist";
        // header("Location: ../adding_record/adding_prisoner?error=".urlencode($message));
        // exit();
    }
}

function IsCellIdValid($prisoner_id, $connection)
{
    $stmt = $connection->prepare("SELECT * FROM prisoners where PrisonerID = ?");
    $stmt->bind_param('i', $prisoner_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return true;
    } else {
        return false;
    }
}
