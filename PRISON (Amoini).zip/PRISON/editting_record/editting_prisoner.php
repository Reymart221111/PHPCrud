<?php
require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";

$record_id = $_GET['id'];

$stmt = $connection->prepare('SELECT * FROM prisoners WHERE PrisonerID = ?');
$stmt->bind_param('i', $record_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Prisoner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        h3 {
            color: #333333;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #555555;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            padding: 10px 20px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3>Adding Prisoner<?php include "../Messages/error_messages.php" ?></h3>
        <form id="prisonerForm" action="../editting_process/edit.prisoner.process.php?id=<?php echo $row['PrisonerID'] ?>" method="POST">
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" value="<?php echo $row['FirstName'] ?>" required>

            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" value="<?php echo $row['LastName'] ?>" required>

            <label for="dateOfBirth">Date of Birth:</label>
            <input type="date" id="dateOfBirth" name="dateOfBirth" value="<?php echo $row['DateOfBirth'] ?>" required>

            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="admissionDate">Admission Date:</label>
            <input type="date" id="admissionDate" name="admissionDate" value="<?php echo $row['AdmissionDate'] ?>" required>

            <label for="description">Crime Description</label>
            <textarea id="description" name="description" rows="4" cols="38"><?php echo $row['CrimeDesc'] ?></textarea>

            <label for="CellID">Cell ID</label>
            <input type="number" id="cellid" name="cellid" value="<?php echo $row['CellID'] ?>" required>

            <input type="submit" value="Add Prisoner">
            <p>
                <center><a href="../index.php#prisoners" style="font-size: 30px;">Exit</a></center>
            </p>
        </form>
    </div>
</body>

</html>