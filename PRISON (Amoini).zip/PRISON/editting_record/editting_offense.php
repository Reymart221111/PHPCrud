<?php
require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";

$record_id = $_GET['id'];

$stmt = $connection->prepare('SELECT * FROM offenses WHERE OffenseID = ?');
$stmt->bind_param('i', $record_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Offenses</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        h3 {
            color: #333333;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #555555;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            padding: 10px 20px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3>Add Prisoner Offenses<?php include "../Messages/error_messages.php" ?></h3>
        <form id="prisonerForm" action="../editting_process/edit.offense.process.php?id=<?php echo $row['OffenseID'] ?>" method="post">
            <label for="p_id">Prisoner ID</label>
            <input type="number" id="p_id" name="p_id" value="<?php echo $row['PrisonerID'] ?>" required>

            <label for="offense_type">Offense</label>
            <input type="text" id="offense_type" name="offense_type" value="<?php echo $row['OffenseDesc'] ?>" required>

            <label for="Offence_date">Offence Commited</label>
            <input type="date" id="offence_date" name="offence_date" value="<?php echo $row['OffenseDate'] ?>"required>


            <input type="submit" value="Edit Offense">\
            <p>
                <center><a href="../index.php#offenses" style="font-size: 30px;">Exit</a></center>
            </p>
        </form>
    </div>
</body>

</html>