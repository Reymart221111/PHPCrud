<?php

try{
    require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";

    $stmt = $connection->prepare("SELECT COUNT(*) as count from prisoners");
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows>0)
    {
        $prisonCount = $result->fetch_assoc();
    }

}catch(Exception $error)
{
    echo "error->".$error->getMessage();
}