<?php
$record_id = $_GET['id'];

try{
    require $_SERVER['DOCUMENT_ROOT'] . "/PRISON/DBSETUP/dbsetup.php";

    $stmt = $connection->prepare('DELETE FROM Cells where CellID=?');
    $stmt->bind_param('i', $record_id);
    
    if($stmt->execute())
    {
        $message = 'record deleted succesfully';
        header("Location: ../index.php?success=".urlencode($message)."#cells");
        exit();
    }

}catch(Exception $error)
{
    echo "Error->".$error->getMessage();
}